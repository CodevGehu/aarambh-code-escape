const express = require('express');
const crypto = require('crypto');
const path = require('path');
const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
const PORT = process.env.PORT || 3000;
const DEV_MODE = process.env.DEV_MODE !== 'false';
const NEXT_ROUND_URL = process.env.NEXT_ROUND_URL || '/round3';
const TCL_LOCATION = { lat:Number(process.env.TCL_LAT || 30.3165), lon:Number(process.env.TCL_LON || 78.0322) };
const PUZZLES={
 cfg_17:{marker:'TCL-07',password:'EMBER-47',qr:'R2QR-7A91C4E2',photo1:'/assets/photos/cfg_17_photo1.jpg',photo2:'/assets/photos/cfg_17_photo2.jpg'},
 cfg_42:{marker:'TCL-14',password:'ORBIT-62',qr:'R2QR-4D72B8F1',photo1:'/assets/photos/cfg_42_photo1.jpg',photo2:'/assets/photos/cfg_42_photo2.jpg'},
 cfg_83:{marker:'TCL-22',password:'VAULT-91',qr:'R2QR-9C13E6A7',photo1:'/assets/photos/cfg_83_photo1.jpg',photo2:'/assets/photos/cfg_83_photo2.jpg'}
};
const sessions=new Map();
const qrToConfig=new Map(Object.entries(PUZZLES).map(([id,p])=>[p.qr,id]));
function rand(n=18){return crypto.randomBytes(n).toString('hex')}
function getSession(t){const s=sessions.get(t); if(!s||Date.now()>s.expiresAt)return null; return s;}
function error(res,status=400,msg='The clue could not be validated.'){return res.status(status).json({ok:false,message:msg});}
function issue(configId){const t=rand(); const code=String(Math.floor(100000+Math.random()*900000)); const now=Date.now(); const s={token:t,code,configId,createdAt:now,expiresAt:now+30*60*1000,qrValidated:false,completed:false}; sessions.set(t,s); return s;}
app.get('/start',(req,res)=>{if(!DEV_MODE)return res.status(404).send('Not found'); const id=req.query.devConfig; if(!PUZZLES[id])return res.status(400).send('Invalid development configuration. Use cfg_17, cfg_42 or cfg_83.'); const s=issue(id); res.redirect('/round2.html?token='+encodeURIComponent(s.token));});
app.get('/api/round2/session',(req,res)=>{const s=getSession(req.query.token); if(!s)return error(res,401); const p=PUZZLES[s.configId]; res.json({ok:true,status:s.qrValidated?'qr_validated':'awaiting_marker',sessionCode:s.code,photo1:p.photo1,expiresAt:s.expiresAt});});
app.get('/api/round2/photo2',(req,res)=>{const s=getSession(req.query.token); if(!s||!s.qrValidated)return error(res,403); res.sendFile(path.join(__dirname,'public',PUZZLES[s.configId].photo2));});
app.get('/scan',(req,res)=>{const qr=String(req.query.qr||''); if(!qrToConfig.has(qr))return res.status(404).send('Unknown marker.'); res.send(`<!doctype html><meta name="viewport" content="width=device-width,initial-scale=1"><title>Code Escape Marker</title><style>body{font-family:system-ui;background:#0d1117;color:#e8edf2;display:grid;place-items:center;min-height:100vh;margin:0}main{max-width:520px;padding:28px}input,button{width:100%;box-sizing:border-box;padding:14px;margin-top:10px;border-radius:10px;border:1px solid #445}button{cursor:pointer;font-weight:700}p{line-height:1.5}</style><main><h1>Physical Marker</h1><p>Enter the six-digit session code shown on your team's Round 2 screen.</p><input id="c" inputmode="numeric" maxlength="6" placeholder="Session code"><button onclick="go()">Validate Marker</button><p id="m"></p><script>async function go(){const code=document.getElementById('c').value.trim();const r=await fetch('/api/round2/scan',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({qr:${JSON.stringify(qr)},code})});const d=await r.json();document.getElementById('m').textContent=d.ok?'Marker accepted. Return to the Round 2 screen.':'Marker could not be validated.';}</script></main>`);});
app.post('/api/round2/scan',(req,res)=>{const qr=String(req.body.qr||''); const code=String(req.body.code||'').trim(); const cfg=qrToConfig.get(qr); if(!cfg)return error(res,403); const s=[...sessions.values()].find(x=>x.code===code&&Date.now()<=x.expiresAt); if(!s||s.configId!==cfg)return error(res,403); s.qrValidated=true; res.json({ok:true});});
app.post('/api/round2/complete',(req,res)=>{const s=getSession(req.body.token); if(!s||!s.qrValidated)return error(res,403); const a=String(req.body.password||'').trim().toUpperCase(); if(a!==PUZZLES[s.configId].password)return error(res,400); s.completed=true; res.json({ok:true,completed:true,nextRound:NEXT_ROUND_URL});});
app.get('/api/round2/dev-info',(req,res)=>{if(!DEV_MODE)return res.status(404).send('Not found'); const s=getSession(req.query.token); if(!s)return error(res,401); const p=PUZZLES[s.configId]; res.json({marker:p.marker,sessionCode:s.code,expectedPassword:p.password,qrToken:p.qr,tclGps:TCL_LOCATION,photo1:p.photo1,photo2:p.photo2});});
app.get('/health',(_,res)=>res.json({ok:true}));
app.listen(PORT,()=>console.log(`Round 2 running on port ${PORT}`));
