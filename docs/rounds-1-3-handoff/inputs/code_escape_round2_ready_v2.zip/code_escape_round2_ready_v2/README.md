# Code Escape — Round 2: The Photograph That Remembers

## Local test
```bash
npm install
npm start
```
Use:
- http://localhost:3000/start?devConfig=cfg_17
- http://localhost:3000/start?devConfig=cfg_42
- http://localhost:3000/start?devConfig=cfg_83

## Test flow
1. Open one development URL.
2. Copy/download Photograph 1.
3. Inspect its EXIF metadata. GPS points to TCL Lab; the metadata also contains TCL-07, TCL-14 or TCL-22 depending on configuration.
4. Go to the matching physical marker and scan its QR.
5. The QR opens a validation page on the scanning phone. Enter the six-digit session code shown on the team's Round 2 screen.
6. Return to the Round 2 screen; Photograph 2 becomes available.
7. Inspect Photograph 2 metadata and extract the password.
8. Submit the password to unlock Round 3.

## Configuration map
- cfg_17 → TCL-07 → EMBER-47
- cfg_42 → TCL-14 → ORBIT-62
- cfg_83 → TCL-22 → VAULT-91

## Important
The GPS coordinates are sample coordinates until the exact TCL Lab coordinates are supplied. Replace TCL_LAT/TCL_LON before deployment.
The public QR images are marker-specific, not team-session-specific. The QR validation therefore uses the six-digit session code as a bridge between the team's desktop session and the phone used to scan the physical marker.
