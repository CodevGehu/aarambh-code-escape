const express = require("express");
const crypto = require("crypto");

const app = express();
const PORT = process.env.PORT || 3000;

// -----------------------------------------------------------------------------
// ROUND 1 PUZZLE CONFIGURATION
// These are server-side. Do NOT put all configurations in public/app.js.
// In production, replace/extend this store with your main Code Escape database.
// -----------------------------------------------------------------------------
const PUZZLES = {
  cfg_17: { x: 17, y: 23, z: 4, answer: "0044" },
  cfg_42: { x: 14, y: 31, z: 3, answer: "0048" },
  cfg_83: { x: 21, y: 19, z: 5, answer: "0045" }
};

// Development/admin testing only.
// Set DEV_MODE=false in production.
// In local testing you can use:
//   /start?devConfig=cfg_17
// This is intentionally NOT accepted when DEV_MODE=false.
const DEV_MODE = process.env.DEV_MODE !== "false";

// Demo launch-token store. Production should persist this mapping in the
// existing Code Escape backend/database and use its authenticated team session.
const launches = new Map();

app.use(express.json());
app.use(express.static("public", { extensions: ["html"] }));

function issueLaunchToken(configId, teamId = "LOCAL-TEST") {
  if (!PUZZLES[configId]) throw new Error("Unknown puzzle configuration");
  const token = crypto.randomBytes(24).toString("hex");
  launches.set(token, {
    teamId,
    configId,
    round: 1,
    createdAt: Date.now(),
    expiresAt: Date.now() + 10 * 60 * 1000,
    used: false
  });
  return token;
}

function getLaunch(token) {
  if (!token) return null;
  const record = launches.get(token);
  if (!record) return null;
  if (record.used || Date.now() > record.expiresAt) {
    launches.delete(token);
    return null;
  }
  return record;
}

function getPuzzleFromRequest(req) {
  const token = req.header("x-round1-token") || req.query.token;
  const launch = getLaunch(token);
  if (!launch) return null;
  return { launch, puzzle: PUZZLES[launch.configId] };
}

// -----------------------------------------------------------------------------
// DEVELOPMENT LAUNCH
// Production should have the original Code Escape backend create the token.
// -----------------------------------------------------------------------------
app.get("/start", (req, res) => {
  if (!DEV_MODE) return res.status(404).send("Not found");

  const configId = req.query.devConfig || "cfg_17";
  if (!PUZZLES[configId]) return res.status(400).send("Unknown development configuration");

  const token = issueLaunchToken(configId, "LOCAL-TEST");
  res.redirect(`/round1.html?token=${encodeURIComponent(token)}`);
});

// -----------------------------------------------------------------------------
// Session bootstrap
// Returns ONLY this team's X and Z to the browser.
// It never returns the internal configuration ID, Y, or expected answer.
// X must be visible to the player because it is the CSS/Computed clue.
// Z must be visible to the player because it is the IndexedDB clue.
// -----------------------------------------------------------------------------
app.get("/api/round1/session", (req, res) => {
  const ctx = getPuzzleFromRequest(req);
  if (!ctx) return res.status(401).json({ error: "Invalid or expired Round 1 session." });

  res.set("Cache-Control", "no-store");
  res.json({ x: ctx.puzzle.x, z: ctx.puzzle.z });
});

// -----------------------------------------------------------------------------
// NETWORK CLUE
// Y is deliberately exposed ONLY as a response header.
// It is not returned in JSON.
// -----------------------------------------------------------------------------
app.get("/api/round1/signal", (req, res) => {
  const ctx = getPuzzleFromRequest(req);
  if (!ctx) return res.status(401).json({ error: "Invalid or expired Round 1 session." });

  res.set("Cache-Control", "no-store");
  res.set("X-Escape-Signal", String(ctx.puzzle.y));
  res.json({ status: "ok" });
});

// -----------------------------------------------------------------------------
// ANSWER VALIDATION
// The expected answer stays server-side.
// -----------------------------------------------------------------------------
app.post("/api/round1/submit", (req, res) => {
  const ctx = getPuzzleFromRequest(req);
  if (!ctx) return res.status(401).json({ correct: false, message: "Invalid or expired Round 1 session." });

  const answer = String(req.body?.answer ?? "").trim();
  const correct = answer === ctx.puzzle.answer;

  res.set("Cache-Control", "no-store");

  if (!correct) {
    return res.json({
      correct: false,
      message: "Incorrect code. Check your three discovered values and try again."
    });
  }

  // Mark this launch token complete. Production should also persist completion
  // against the main Code Escape team/session.
  ctx.launch.used = true;

  res.json({
    correct: true,
    message: "Round 1 complete. Returning to Code Escape...",
    // Configure this in production through an environment variable.
    nextRound: process.env.NEXT_ROUND_URL || "/complete.html"
  });
});

// Health check for hosting platforms.
app.get("/health", (_req, res) => res.json({ ok: true }));

app.listen(PORT, () => {
  console.log(`Round 1 running on port ${PORT}`);
  console.log(`DEV_MODE=${DEV_MODE}`);
});
