# Code Escape Room — Round 1 Ready Version

## What this version fixes

This version removes the insecure production pattern where participants could choose
`?set=A`, `?set=B`, or `?set=C` and where all three puzzle configurations were exposed
inside `app.js`.

Production flow:

Main Code Escape -> temporary launch token -> Round 1 -> server-side puzzle configuration
-> answer validation -> Main Code Escape Round 2.

The participant never receives an internal configuration/set name.

## Current puzzle configurations

- cfg_17: X=17, Y=23, Z=4 -> 0044
- cfg_42: X=14, Y=31, Z=3 -> 0048
- cfg_83: X=21, Y=19, Z=5 -> 0045

These identifiers are internal development labels. Do not expose them to players.

## Local setup

Requirements: Node.js 18+.

```bash
npm install
npm start
```

Open:

http://localhost:3000/start?devConfig=cfg_17

For local testing of the other configurations:

http://localhost:3000/start?devConfig=cfg_42

http://localhost:3000/start?devConfig=cfg_83

These /start development routes exist only while DEV_MODE is true. Set DEV_MODE=false
for a production deployment.

## How to test the puzzle

1. Open the development URL.
2. Open Chrome/Edge DevTools.
3. Inspect the relevant element and use Computed styles to find X.
4. Click Wake the Server.
5. In Network, inspect the response headers and find X-Escape-Signal (Y).
6. In Application -> IndexedDB -> CodeEscape -> clues, find round1 (Z).
7. Calculate X + Y + Z.
8. Enter exactly four digits.
9. Verify that the correct answer succeeds and an incorrect answer does not reveal which value is wrong.

## Hosting

Recommended simple hosting for this Node/Express app: Render or another Node web-service host.

GitHub:
1. Create a private/public repository for the project.
2. Push this folder.
3. Create a Web Service on Render.
4. Connect the repository.
5. Build command: `npm install`
6. Start command: `npm start`
7. Set environment variables:
   DEV_MODE=false
   NEXT_ROUND_URL=https://YOUR-CODE-ESCAPE-DOMAIN/round/2
8. Deploy.
9. Confirm `GET /health` returns `{"ok":true}`.

Do not commit `.env` or production secrets.

## Production integration

The current code contains a small in-memory launch-token store for demonstrating the
architecture. For the real event, the existing Code Escape backend should issue the
launch token and store the mapping:

random token -> authenticated team -> internal puzzle configuration -> Round 1.

Round 1 should validate that token server-side and report completion back to the
main Code Escape backend.

Do not use the development /start route or devConfig parameter for participants.

## Important production note

This is production-oriented Round 1 code, but the final cross-application authentication
and completion callback must be integrated with the actual Code Escape backend. The exact
API/authentication contract was not provided in the event documents, so this package does
not invent that contract.

The participant-facing browser still necessarily receives X and Z because those values
are the intended DevTools clues. Y is deliberately exposed only through the Network
response header. The expected answer and all other puzzle configurations remain server-side.
