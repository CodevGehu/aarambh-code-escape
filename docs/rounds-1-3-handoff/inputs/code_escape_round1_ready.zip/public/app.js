const params = new URLSearchParams(window.location.search);
const token = params.get("token");

const wakeButton = document.getElementById("wakeButton");
const networkStatus = document.getElementById("networkStatus");
const answerForm = document.getElementById("answerForm");
const result = document.getElementById("result");

if (!token) {
  result.textContent = "This Round 1 link is missing its launch token.";
  result.className = "result error";
  wakeButton.disabled = true;
  document.getElementById("answer").disabled = true;
  throw new Error("Missing Round 1 token");
}

// The token is the only launch identifier visible to the browser.
// There is NO set name and no A/B/C mapping in this client.
async function bootstrap() {
  const response = await fetch(`/api/round1/session?token=${encodeURIComponent(token)}`, {
    cache: "no-store"
  });
  if (!response.ok) throw new Error("Invalid or expired session");

  const data = await response.json();

  // X must be discoverable through Computed styles.
  document.documentElement.style.setProperty("--round1-x", String(data.x));

  // Z must be discoverable through IndexedDB.
  const DB_NAME = "CodeEscape";
  const STORE_NAME = "clues";

  const dbRequest = indexedDB.open(DB_NAME, 1);
  dbRequest.onupgradeneeded = (event) => {
    const db = event.target.result;
    if (!db.objectStoreNames.contains(STORE_NAME)) {
      db.createObjectStore(STORE_NAME);
    }
  };
  dbRequest.onsuccess = (event) => {
    const db = event.target.result;
    const tx = db.transaction(STORE_NAME, "readwrite");
    tx.objectStore(STORE_NAME).put(data.z, "round1");
  };
}

bootstrap().catch(() => {
  result.textContent = "Unable to initialize this Round 1 session.";
  result.className = "result error";
  wakeButton.disabled = true;
  document.getElementById("answer").disabled = true;
});

wakeButton.addEventListener("click", async () => {
  networkStatus.textContent = "Signal requested. Inspect the Network request.";

  try {
    const response = await fetch(`/api/round1/signal?token=${encodeURIComponent(token)}`, {
      cache: "no-store"
    });

    if (!response.ok) throw new Error("request failed");
    networkStatus.textContent = "The server answered. Find the response header.";
  } catch {
    networkStatus.textContent = "The server could not be reached.";
  }
});

answerForm.addEventListener("submit", async (event) => {
  event.preventDefault();

  result.textContent = "Checking...";
  result.className = "result";

  const answer = document.getElementById("answer").value.trim();

  try {
    const response = await fetch(`/api/round1/submit?token=${encodeURIComponent(token)}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ answer })
    });

    const data = await response.json();

    if (data.correct) {
      result.textContent = data.message;
      result.className = "result success";
      setTimeout(() => {
        window.location.href = data.nextRound;
      }, 900);
    } else {
      result.textContent = data.message;
      result.className = "result error";
    }
  } catch {
    result.textContent = "Server error. Please try again.";
    result.className = "result error";
  }
});
