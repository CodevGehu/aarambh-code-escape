# Code Escape Round 3 — The Black Box (FINAL)

## Local test

1. Install Node.js.
2. From this folder run:

   npm install
   npm start

3. Open one of these organizer test URLs:

   http://localhost:3000/start?devConfig=cfg_17
   http://localhost:3000/start?devConfig=cfg_42
   http://localhost:3000/start?devConfig=cfg_83

## Intended rule

For a letter at alphabet position n (A=1), the machine shifts it by:

base + 1 + 2 + ... + (n-1)

wrapping after Z.

cfg_17: base 5 -> A F, B H, C K, D O, E T -> final code T
cfg_42: base 3 -> A D, B F, C I, D M, E R -> final code R
cfg_83: base 7 -> A H, B J, C M, D Q, E V -> final code V

The player UI does not show configuration IDs or the rule. The server validates probes and the final code.

## Production

The /start?devConfig=... route is development-only. In production set DEV_MODE=false and integrate the existing Code Escape backend so a temporary authenticated launch token maps server-side to the team's assigned configuration.

Do not expose set/config IDs in participant URLs.
