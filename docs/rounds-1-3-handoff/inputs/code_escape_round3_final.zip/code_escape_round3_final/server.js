const express = require('express');
const crypto = require('crypto');

const app = express();
const PORT = process.env.PORT || 3000;
const DEV_MODE = process.env.DEV_MODE !== 'false';

app.use(express.json());
app.use(express.static('public'));

// Three internal variants. Players never see these IDs.
// Rule: shift = base + triangular(position - 1), then wrap A-Z.
// cfg_17 reproduces the intended visible example:
// A->F, B->H, C->K, D->O, E->T.
const PUZZLES = {
  cfg_17: { base: 5, finalInput: 'E', finalCode: 'T' },
  cfg_42: { base: 3, finalInput: 'E', finalCode: 'R' },
  cfg_83: { base: 7, finalInput: 'E', finalCode: 'V' }
};

const sessions = new Map();

function token() { return crypto.randomBytes(24).toString('hex'); }
function getSession(req) {
  const t = req.query.token;
  return t ? sessions.get(t) : null;
}
function normChar(value) {
  const s = String(value ?? '').trim().toUpperCase();
  return /^[A-Z]$/.test(s) ? s : null;
}
function transform(ch, base) {
  const p = ch.charCodeAt(0) - 64; // A=1 ... Z=26
  const triangular = (p * (p - 1)) / 2;
  const shift = base + triangular;
  const out = ((p - 1 + shift) % 26) + 1;
  return String.fromCharCode(64 + out);
}
function examples(puzzle) {
  return ['A','B','C','D'].map(input => [input, transform(input, puzzle.base)]);
}

app.get('/start', (req, res) => {
  if (!DEV_MODE) return res.status(404).send('Not found');
  const configId = req.query.devConfig || 'cfg_17';
  if (!PUZZLES[configId]) return res.status(400).send('Unknown development configuration.');
  const t = token();
  sessions.set(t, {
    configId,
    probesUsed: 0,
    completed: false,
    createdAt: Date.now()
  });
  res.redirect(`/round3.html?token=${encodeURIComponent(t)}`);
});

app.get('/api/round3/session', (req, res) => {
  const s = getSession(req);
  if (!s) return res.status(401).json({ error: 'Invalid session.' });
  const puzzle = PUZZLES[s.configId];
  res.json({
    examples: examples(puzzle),
    finalInput: puzzle.finalInput,
    maxProbes: 6
  });
});

app.post('/api/round3/probe', (req, res) => {
  const s = getSession(req);
  if (!s) return res.status(401).json({ error: 'Invalid session.' });
  if (s.completed) return res.status(400).json({ error: 'Round already completed.' });
  if (s.probesUsed >= 6) return res.status(429).json({ error: 'Probe limit reached.' });

  const input = normChar(req.body.input);
  if (!input) return res.status(400).json({ error: 'Enter one letter from A to Z.' });

  s.probesUsed += 1;
  const output = transform(input, PUZZLES[s.configId].base);
  res.json({ input, output, probesUsed: s.probesUsed, probesRemaining: 6 - s.probesUsed });
});

app.post('/api/round3/submit', (req, res) => {
  const s = getSession(req);
  if (!s) return res.status(401).json({ error: 'Invalid session.' });
  if (s.completed) return res.status(400).json({ error: 'Round already completed.' });

  const answer = normChar(req.body.answer);
  const expected = PUZZLES[s.configId].finalCode;
  if (answer !== expected) {
    return res.status(400).json({ correct: false, message: 'Incorrect code.' });
  }

  s.completed = true;
  res.json({ correct: true, nextRound: 4, message: 'Correct. Round 4 unlocked.' });
});

// Organizer-only testing endpoint. Never enabled in production.
app.get('/api/round3/dev-info', (req, res) => {
  if (!DEV_MODE) return res.status(404).json({ error: 'Not found' });
  const s = getSession(req);
  if (!s) return res.status(401).json({ error: 'Invalid session.' });
  const p = PUZZLES[s.configId];
  res.json({ configId: s.configId, finalInput: p.finalInput, expectedCode: p.finalCode, probesUsed: s.probesUsed });
});

app.get('/health', (_req, res) => res.json({ ok: true, service: 'code-escape-round3' }));

app.listen(PORT, () => {
  console.log(`Round 3 running on port ${PORT}`);
  if (DEV_MODE) {
    console.log('Development test URLs:');
    for (const id of Object.keys(PUZZLES)) console.log(`  http://localhost:${PORT}/start?devConfig=${id}`);
  }
});
